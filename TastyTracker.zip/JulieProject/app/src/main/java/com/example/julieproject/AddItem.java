package com.example.julieproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class AddItem extends AppCompatActivity {
    private EditText itemNameEditText;
    private EditText itemQuantityEditText;
    private Button saveButton;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        saveButton = findViewById(R.id.saveButton);

        username = MainActivity.username;

        String itemName = getIntent().getStringExtra("ITEM_NAME");
        int itemQuantity = getIntent().getIntExtra("ITEM_QUANTITY", 0);

        if (itemName != null) {
            itemNameEditText.setText(itemName);
            itemQuantityEditText.setText(String.valueOf(itemQuantity));
        }

        saveButton.setOnClickListener(v -> {
            String itemNameInput = itemNameEditText.getText().toString().trim();
            String itemQuantityInput = itemQuantityEditText.getText().toString().trim();

            if (itemNameInput.isEmpty() || itemQuantityInput.isEmpty()) {
                Toast.makeText(AddItem.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            saveOrUpdateItem(itemNameInput, Integer.parseInt(itemQuantityInput));

            Intent intent = new Intent(AddItem.this, SecondActivity.class);
            intent.putExtra("USERNAME", username);
            startActivity(intent);
        });
    }

    private void saveOrUpdateItem(String itemName, int itemQuantity) {
        trackerDBAdapter dbAdapter = new trackerDBAdapter(this);
        dbAdapter.open(username);

        if (dbAdapter.itemExists(username, itemName)) {
            dbAdapter.updateCurrentItem(username, itemName, itemQuantity);
        } else {
            dbAdapter.insertCurrentItem(username, itemName, itemQuantity);
        }

        dbAdapter.printCurrentItems(username);
        dbAdapter.close();

        Intent resultIntent = new Intent();
        resultIntent.putExtra("ITEM_NAME", itemName);
        resultIntent.putExtra("ITEM_QUANTITY", itemQuantity);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}
