package com.example.julieproject;

import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.content.Intent;
import java.util.ArrayList;

public class ViewShoppingList extends AppCompatActivity {
    private ListView shoppingListView;
    private ArrayAdapter<String> adapter;
    private Button backButton;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_shopping_list);

        Log.d("ViewShopping", "I AM VIEWING THE SHOPPING!");

        shoppingListView = findViewById(R.id.shoppingListView);
        backButton = findViewById(R.id.backButton);

        username = MainActivity.username;

        ArrayList<String> shoppingListItems = retrieveShoppingListItemsFromDatabase();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, shoppingListItems);
        shoppingListView.setAdapter(adapter);

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(ViewShoppingList.this, SecondActivity.class);
            intent.putExtra("USERNAME", username);
            startActivity(intent);
        });
    }

    private ArrayList<String> retrieveShoppingListItemsFromDatabase() {
        ArrayList<String> shoppingListItems = new ArrayList<>();
        trackerDBAdapter dbAdapter = new trackerDBAdapter(this);
        dbAdapter.open(username);

        Cursor cursor = dbAdapter.getShoppingListItems(username);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int index = cursor.getColumnIndex(trackerDBAdapter.KEY_ITEM);
                String itemName = "";
                if (index >= 0) {
                    itemName = cursor.getString(index);
                }
                shoppingListItems.add(itemName);
            } while (cursor.moveToNext());
            cursor.close();
        }

        dbAdapter.close();
        return shoppingListItems;
    }
}


