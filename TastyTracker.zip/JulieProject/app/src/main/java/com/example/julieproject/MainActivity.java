package com.example.julieproject;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText usernameEditText, passwordEditText;
    Button loginButton, registerButton;
    userInfoDBAdapter userInfoDB;
    public trackerDBAdapter db = new trackerDBAdapter(this);
    public static String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        userInfoDB = new userInfoDBAdapter(this);
        userInfoDB.open();



        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                login(username, password);
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = usernameEditText.getText().toString();
                final String password = passwordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Username and password cannot be empty!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(!Character.isLetter(username.charAt(0))){
                    Toast.makeText(MainActivity.this, "Username must start with a letter", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if username already exists
                if (ifUsernameExists(username)) {
                    Toast.makeText(MainActivity.this, "Username already exists. Please choose a different username.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Register the user
                long result = userInfoDB.insertUser(username, password);
                if (result != -1) {
                    Toast.makeText(MainActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Failed to register user!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void login(String username, String password) {
        Cursor cursor = userInfoDB.getAllUsers();
        boolean isUsernameFound = false;
        int usernameIndex = cursor.getColumnIndex(userInfoDBAdapter.KEY_USERNAME);
        int passwordIndex = cursor.getColumnIndex(userInfoDBAdapter.KEY_PASSWORD);

        if (cursor.moveToFirst()) {
            do {
                String storedUsername = cursor.getString(usernameIndex);
                String storedPassword = cursor.getString(passwordIndex);

                if (storedUsername != null && storedUsername.equals(username)) {
                    isUsernameFound = true;
                    if (storedPassword != null && storedPassword.equals(password)) {
                        // Password is correct
                        showLoginSuccessToast();
                        Log.d("END OF MAIN", "~~~~~~~~~~~~~~~~~~~~~~~~~");
                        userInfoDB.close();
                        cursor.close();
                        openSecondActivity(username);
                        return;
                    } else {
                        showPasswordIncorrectAlert();
                        return;
                    }
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        if (!isUsernameFound) {
            showUsernameNotFoundToast();
        }
    }


    private boolean ifUsernameExists(String username) {
        Cursor cursor = userInfoDB.getAllUsers();
        boolean exists = false;
        int usernameIndex = cursor.getColumnIndex(userInfoDBAdapter.KEY_USERNAME);

        if (cursor.moveToFirst()) {
            do {
                String storedUsername = cursor.getString(usernameIndex);
                if (storedUsername != null && storedUsername.equals(username)) {
                    exists = true;
                    break;
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return exists;
    }


    private void showLoginSuccessToast() {
        Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
    }

    private void showUsernameNotFoundToast() {
        Toast.makeText(MainActivity.this, "Username not found!", Toast.LENGTH_SHORT).show();
    }

    private void showPasswordIncorrectAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Password Incorrect")
                .setMessage("The password you entered is incorrect.")
                .setPositiveButton("OK", null)
                .create()
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userInfoDB.close();
    }

    private void openSecondActivity(String username) {
        Intent intent = new Intent(MainActivity.this, SecondActivity.class);
        intent.putExtra("USERNAME", username);
        startActivity(intent);
        finish();
    }

    public static String getUsername(){
        return username;
    }
}


