package com.example.julieproject;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {
    private ListView listView;
    private CustomAdapter adapter;
    private trackerDBAdapter db;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        username = MainActivity.username;

        listView = findViewById(R.id.listView);

        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondActivity.this, AddItem.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        Button viewSLButton = findViewById(R.id.viewShoppingListButton);
        viewSLButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondActivity.this, ViewShoppingList.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        LoadList loadItemsTask = new LoadList();
        loadItemsTask.execute(username);
    }

    private class LoadList extends AsyncTask<String, Void, ArrayList<Item>> {
        @Override
        protected ArrayList<Item> doInBackground(String... params) {
            String username = params[0];
            db = new trackerDBAdapter(SecondActivity.this);
            db.open(username);
            Log.d("CMON MAN", "username: " + username);
            return db.getAllItems(username);
        }

        @Override
        protected void onPostExecute(ArrayList<Item> itemList) {
            super.onPostExecute(itemList);
            adapter = new CustomAdapter(SecondActivity.this, itemList, username);
            listView.setAdapter(adapter);
            db.close();
        }
    }
}



