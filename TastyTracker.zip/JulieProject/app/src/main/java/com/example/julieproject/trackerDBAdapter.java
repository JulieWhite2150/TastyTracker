package com.example.julieproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class trackerDBAdapter{
    static final String KEY_ROWID = "_id";
    static final String KEY_ITEM = "item";
    static final String KEY_QUANTITY = "quantity";
    static final String TAG = "TrackerDBAdapter";
    static final int DATABASE_VERSION = 1;
    final Context context;
    DatabaseHelper DBHelper;
    SQLiteDatabase db;

    public trackerDBAdapter(Context ctx) {
        this.context = ctx;
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {
        String username;

        DatabaseHelper(Context context, String username) {
            super(context, username + "_database", null, DATABASE_VERSION);
            this.username = username;
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String createCurrentItemsTableQuery = "CREATE TABLE IF NOT EXISTS ";
            createCurrentItemsTableQuery += username + "_currentItems";
            createCurrentItemsTableQuery += " (" + KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, ";
            createCurrentItemsTableQuery += KEY_ITEM + " TEXT, ";
            createCurrentItemsTableQuery += KEY_QUANTITY + " INTEGER);";

            String createShoppingListTableQuery = "CREATE TABLE IF NOT EXISTS ";
            createShoppingListTableQuery += username + "_shoppingList";
            createShoppingListTableQuery += " (" + KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, ";
            createShoppingListTableQuery += KEY_ITEM + " TEXT);";

            try {
                db.execSQL(createCurrentItemsTableQuery);
                db.execSQL(createShoppingListTableQuery);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + username + "_currentItems");
            db.execSQL("DROP TABLE IF EXISTS " + username + "_shoppingList");
            onCreate(db);
        }
    }

    public trackerDBAdapter open(String username) throws SQLException {
        DBHelper = new DatabaseHelper(context, username);
        db = DBHelper.getReadableDatabase();
        return this;
    }

    public void close() {
        DBHelper.close();
    }

    public long insertCurrentItem(String username, String item, int quantity) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_ITEM, item);
        initialValues.put(KEY_QUANTITY, quantity);
        return db.insert(username + "_currentItems", null, initialValues);
    }

    public long insertShoppingListItem(String username, String item) {
        ContentValues initialValues = new ContentValues();
        Log.d("TRACKER","username: " + username);
        initialValues.put(KEY_ITEM, item);
        return db.insert(username + "_shoppingList", null, initialValues);
    }

    public Cursor getShoppingListItems(String username) {
        if (db == null || !db.isOpen()) {
            return null;
        }

        String tableName = username + "_shoppingList";
        String[] columns = new String[]{KEY_ITEM};
        return db.query(tableName, columns, null, null, null, null, null);
    }

    public ArrayList<Item> getAllItems(String username) {
        ArrayList<Item> itemList = new ArrayList<>();

        if (db == null || !db.isOpen()) {
            return itemList;
        }

        String tableName = username + "_currentItems";
        String[] columns = new String[]{KEY_ITEM, KEY_QUANTITY};
        Cursor cursor = db.query(tableName, columns, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String itemName = cursor.getString(cursor.getColumnIndex(KEY_ITEM));
                int itemQuantity = cursor.getInt(cursor.getColumnIndex(KEY_QUANTITY));
                itemList.add(new Item(itemName, itemQuantity));
            }
            cursor.close();
        }

        return itemList;
    }


    public boolean itemExists(String username, String itemName) {
        Cursor cursor = db.query(username + "_currentItems", new String[]{KEY_ITEM}, KEY_ITEM + "=?", new String[]{itemName}, null, null, null);
        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) {
            cursor.close();
        }
        return exists;
    }

    public void updateCurrentItem(String username, String itemName, int itemQuantity) {
        ContentValues values = new ContentValues();
        values.put(KEY_QUANTITY, itemQuantity);
        db.update(username + "_currentItems", values, KEY_ITEM + "=?", new String[]{itemName});
    }

    public void printCurrentItems(String username) {
        SQLiteDatabase db = DBHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + username + "_currentItems", null);

        try {
            if (cursor.moveToFirst()) {
                do {
                    String itemName = cursor.getString(cursor.getColumnIndex(KEY_ITEM));
                    int quantity = cursor.getInt(cursor.getColumnIndex(KEY_QUANTITY));
                    Log.d(TAG, "Item: " + itemName + ", Quantity: " + quantity);
                } while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
        }
    }
}


